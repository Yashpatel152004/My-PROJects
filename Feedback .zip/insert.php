<!DOCTYPE html>
<html>
 
<head>
    <title>Insert Page page</title>
</head>
 
<body>
    <center>
        <?php
         servername = localhost;
         username = root;
         password = "";
         database name = feedback;
        $conn = mysqli_connect("localhost", "root", "", "feedback");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
         
        // Taking all 5 values from the form data(input)
        $Entername =  $_REQUEST['Enter_name'];
        $Enteremail = $_REQUEST['Enter_email'];
        $EnrollmentNumber =  $_REQUEST['Enrollment_Number'];
        $MobileNumber = $_REQUEST['Mobile_Number'];
        $Description = $_REQUEST['Description'];
         
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO college  VALUES ('$Enter_name',
            '$Enter_email','$Enrollment_Number','$Mobile_Number','$Description')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";
 
            echo nl2br("\n$Enter_name\n $Enter_email\n "
                . "$Enrollment_Number\n $Mobile_Number\n $Description");
        } else{
            echo "ERROR: Hush! Sorry $sql. "
                . mysqli_error($conn);
        }
         
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>